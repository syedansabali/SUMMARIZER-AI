import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  onAuthStateChanged, 
  User 
} from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyB5GseOcJKgT90UWKoSg2NUT0isZDHDTz8",
  authDomain: "summarizer-ai-1b05e.firebaseapp.com",
  projectId: "summarizer-ai-1b05e",
  storageBucket: "summarizer-ai-1b05e.firebasestorage.app",
  messagingSenderId: "989244826756",
  appId: "1:989244826756:web:2ded5401d27a83393b4ed1",
  measurementId: "G-WPDG7PNC55"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('email');
googleProvider.addScope('profile');

export { signInWithPopup, signInWithRedirect, getRedirectResult, onAuthStateChanged };
export type { User };
