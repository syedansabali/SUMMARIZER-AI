import { Link, useLocation } from 'react-router-dom';
import { Search, User, Languages, Book, LogOut, LayoutDashboard } from 'lucide-react';
import { Button } from '@/src/components/ui/Button';
import { cn } from '../../lib/utils';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../AuthProvider';
import { useNavigate } from 'react-router-dom';

export function Navbar() {
  const { t, i18n } = useTranslation();
  const { user, login, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLoginClick = async () => {
    if (user) {
      navigate('/dashboard');
      return;
    }
    const loggedInUser = await login();
    if (loggedInUser) {
      navigate('/dashboard');
    }
  };

  const isDashboard = location.pathname.startsWith('/dashboard') || 
                      location.pathname === '/processing' || 
                      location.pathname === '/reader';

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
  };

  // Get display name — show first name only to keep it short
  const getDisplayName = () => {
    if (!user) return '';
    if (user.displayName) {
      return user.displayName.split(' ')[0]; // First name only
    }
    if (user.email) {
      return user.email.split('@')[0]; // Part before @
    }
    return 'User';
  };

  return (
    <header className="bg-surface/30 backdrop-blur-xl border-b border-white/10 top-0 sticky z-50 shadow-[0_0_20px_rgba(73,75,214,0.1)]">
      <nav className="flex justify-between items-center w-full px-6 py-4 max-w-7xl mx-auto">
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-tr from-secondary to-primary rounded-lg shadow-lg flex items-center justify-center">
              <Book className="w-5 h-5 text-white" />
            </div>
            <span className="font-headline text-lg font-extrabold tracking-tighter">
              SUMMARIZER <span className="font-light opacity-60">AI</span>
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8 ml-4">
            <Link 
              to="/dashboard" 
              className={cn(
                "text-[10px] font-bold uppercase tracking-widest transition-colors",
                location.pathname === '/dashboard' 
                  ? "text-secondary border-b border-secondary pb-1" 
                  : "opacity-60 hover:opacity-100"
              )}
            >
              {t('nav.dashboard')}
            </Link>
            <a className="text-[10px] font-bold uppercase tracking-widest opacity-60 hover:opacity-100 transition-colors" href="#">Docs</a>
            <a className="text-[10px] font-bold uppercase tracking-widest opacity-60 hover:opacity-100 transition-colors" href="#">{t('nav.pricing')}</a>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* Language Selector */}
          <div className="flex items-center gap-1 group relative">
            <Languages className="w-4 h-4 text-on-surface-variant group-hover:text-primary transition-colors" />
            <select 
              value={i18n.language}
              onChange={(e) => changeLanguage(e.target.value)}
              className="bg-transparent text-[10px] uppercase font-bold tracking-widest border-none focus:ring-0 cursor-pointer opacity-60 hover:opacity-100 transition-opacity"
            >
              <option value="en" className="bg-surface text-white">EN</option>
              <option value="fr" className="bg-surface text-white">FR</option>
              <option value="es" className="bg-surface text-white">ES</option>
            </select>
          </div>

          {/* Search bar — only on dashboard */}
          {isDashboard && (
            <div className="hidden lg:relative lg:block">
              <input 
                className="bg-surface-container-lowest border border-white/10 rounded-xl px-4 py-2 w-64 focus:outline-none focus:border-primary/50 transition-all text-xs" 
                placeholder={t('nav.search')} 
                type="text"
              />
              <Search className="absolute right-3 top-2.5 w-4 h-4 text-on-surface-variant" />
            </div>
          )}
          
          {/* AUTH SECTION */}
          {user ? (
            // ✅ LOGGED IN: Show profile picture + username + logout
            <div className="flex items-center gap-3">
              <button 
                onClick={() => navigate('/dashboard')}
                className="flex items-center gap-2 hover:opacity-80 transition-opacity"
              >
                {user.photoURL ? (
                  <img 
                    src={user.photoURL} 
                    alt={getDisplayName()} 
                    className="w-8 h-8 rounded-full border-2 border-primary/40 shadow-md" 
                    referrerPolicy="no-referrer" 
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center border-2 border-primary/40">
                    <User className="w-4 h-4 text-primary" />
                  </div>
                )}
                <span className="hidden md:block text-xs font-bold text-on-surface max-w-[120px] truncate">
                  {getDisplayName()}
                </span>
              </button>
              <button 
                onClick={logout}
                title="Logout"
                className="text-red-400/60 hover:text-red-400 transition-colors p-1"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            // ✅ LOGGED OUT: Show Login + Sign Up buttons
            <div className="flex items-center gap-3">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleLoginClick} 
                className="text-[10px] uppercase font-bold"
              >
                {t('nav.login')}
              </Button>
              <Button 
                variant="primary" 
                size="sm" 
                onClick={handleLoginClick}
              >
                Sign Up
              </Button>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
}
